package com.example.demo.Controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Entidades.Producto;
import com.example.demo.Repositorios.RepositorioProductos;

@RequestMapping("/tienda")
@RestController
public class Controlador {

	@Autowired
	private RepositorioProductos repositorioProductos;
	
	//USAMOS RESPONSEENTITY PARA MANEJAR LAS RESPUESTAS

	
	
	@GetMapping("/lista")
	public  ResponseEntity<List<Producto> >  listaProductos() {
		if(repositorioProductos.findAll().isEmpty()) {
			Producto x = new Producto("teclado",20);
			Producto y =new Producto("raton",15);
			
			repositorioProductos.save(x);
			repositorioProductos.save(y);
			System.out.println("cargads productos");
			
		}
		return ResponseEntity.ok(repositorioProductos.findAll());
	}
	
	@PostMapping("/nuevo")
	public ResponseEntity<String> crearProducto(@RequestBody Producto producto) {
		if(repositorioProductos.findByNombre(producto.getNombre()).isPresent()  ) {
			return ResponseEntity.badRequest().body("Error:producto ya existe");
		}
		
		repositorioProductos.save(producto);
		
		return ResponseEntity.ok("Producto creado correctamente");
	}
	
	@PutMapping("/actualizar/{id}")
	public ResponseEntity<String> actualizarProducto(@PathVariable("id") Long id ,@RequestBody Producto producto){
		
		
		if(!repositorioProductos.existsById(id)) {
			System.out.println("no modificado");
			return ResponseEntity.badRequest().body("El producto no existe");
		}
		producto.setId(id);
		repositorioProductos.save(producto);
		return ResponseEntity.ok("producto odificado");
		

	}
	
	@DeleteMapping("/borrar/{id}")
	public ResponseEntity<String> borrarProducto(@PathVariable("id")   Long id) {
	    if (!repositorioProductos.existsById(id)) {
	        return ResponseEntity.badRequest().body("Error: El producto no existe");
	    }
	    
	    repositorioProductos.deleteById(id);
	    return ResponseEntity.ok("Producto eliminado correctamente");
	}

	
	
	
	
}
