package com.quizsql.demo;

public class Juego {
	private int numeroAdivinar;
	private int intentos;
	
	public Juego() {
		reiniciar();
	}
	public void reiniciar() {
		this.numeroAdivinar=(int)(Math.random()*100)+1;
		this.intentos=0;
	}
	public boolean esNumeroCorrecto(int numero) {
		intentos++;
		return numero == numeroAdivinar;
	}
	public String obtenerPista(int numero) {
        if (numero < numeroAdivinar) {
            return "El número es mayor.";
        } else if (numero > numeroAdivinar) {
            return "El número es menor.";
        } else {
            return "¡Correcto!";
        }
    }

	public int getIntentos() {
        return intentos;
    }

}

