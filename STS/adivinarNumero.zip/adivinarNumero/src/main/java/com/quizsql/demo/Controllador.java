package com.quizsql.demo;

import java.util.Scanner;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
public class Controllador {
	private final Juego juego=new Juego();
	@GetMapping("/")
	public String inicio() {
		return "index";
	}
	@PostMapping("/adivinar")
	public String adivinar(@RequestParam(value = "numero", required = false)String numeroIngresado,Model model) {
		if(numeroIngresado==null || numeroIngresado.trim().isEmpty()) {
			model.addAttribute("mensaje", "ingrese el numero");
			return"index";
		}
		int numero=Integer.parseInt(numeroIngresado.trim());
		boolean esCorrecto=juego.esNumeroCorrecto(numero);
		String pista = juego.obtenerPista(numero);
		
		model.addAttribute("pista",pista);
		model.addAttribute("intentos",juego.getIntentos());
		model.addAttribute("esCorrecto",esCorrecto);
		if(esCorrecto) {
			return"resultado";
		}else {
			return "index";
		}
	}
	@GetMapping("/reiniciar")
	public String reiniciar() {
		juego.reiniciar();
		return "redirect:/";
	}
}
