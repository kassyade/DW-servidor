package ies.goya.examen.ud5.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ies.goya.examen.ud5.model.Email;

public interface RepositorioEmail extends JpaRepository <Email,Long>{

}
