package com.example.demo.entities;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Autor {

	@Id
    @NotNull(message="El autor necesita una id")
    @Min(value = 1, message = "La ID debe ser mayor que 0")
    private Long id;
	@NotBlank(message="El autor necesita un nombre")
	private String nombre;
	@NotBlank(message="El autor necesita un estilo ")
    private String estilo;  
	
	private Autor (Long id,String nombre , String estilo ) {
		this.id=id;
		this.nombre=nombre;
		this.estilo=estilo;
	}
	
	public Autor() {
		super();
	}

	public  Long getId() {
		return id;
	}
	public void setId( Long id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public  String getEstilo() {
		return estilo;
	}

	public void setEstilo(String estilo) {
		this.estilo = estilo;
	}



	
	
	
	
}
