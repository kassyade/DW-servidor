package com.example.demo.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Libro {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@NotBlank(message="El libro necesita un nombre")
	private String nombre;
	@NotBlank(message="El libro necesita un genero")
	private String genero;
	@NotNull(message="Necesitamos una fecha de publicación")
	private LocalDate fechaPublicacion;
	
	
	@ManyToOne
	@JoinColumn(name="autor_id",nullable=false)
	private Autor autor;

	

	private Libro(String nombre ,String genero,LocalDate fechaPublicacion) {
		this.nombre=nombre;
		this.genero=genero;
		this.fechaPublicacion=fechaPublicacion;
	}

	public Libro() {
	}
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public LocalDate getFechaPublicacion() {
		return fechaPublicacion;
	}


	public void setFechaPublicacion(LocalDate fechaPublicacion) {
		this.fechaPublicacion = fechaPublicacion;
	}


	public Autor getAutor() {
		return autor;
	}


	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	
	
	
}
