package com.example.demo;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record Quote(
    Long id, 
    String name, 
    String status, 
    String species, 
    String type, 
    String gender, 
    Origin origin, 
    Location location, 
    String image
) {}
