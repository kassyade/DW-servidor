package ies.goya.examen.ud5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionaAlumnosUd5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
