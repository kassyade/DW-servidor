package ies.goya.examen.ud5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionaAlumnosUd5Application {

	public static void main(String[] args) {
		SpringApplication.run(GestionaAlumnosUd5Application.class, args);
	}

}
