package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;

@Controller
public class Controlador {

	@Autowired
	private RepositorioAutor repositorioAutor;
	@Autowired
	private RepositorioLibro repositorioLibro;
	
	
	@GetMapping("/")
	public String inicio(Model model, Autor autor,Libro libro){
		model.addAttribute("autor",autor);
	    model.addAttribute("autores", repositorioAutor.findAll()); 
	    model.addAttribute("libro",libro);
	    model.addAttribute("libros", repositorioLibro.findAll());
		return"alejandria";
	}
	
	
	@PostMapping("/crearAutor")
	public String agregarAutor(Model model, @Valid Autor autor, BindingResult resultado) {
	    if (resultado.hasErrors()) {
	        System.out.println("Errores encontrados");
	        model.addAttribute("libro", new Libro()); // ???? pruebas
	        model.addAttribute("autores", repositorioAutor.findAll()); 
	        return "alejandria";
	    } else {
	        if (repositorioAutor.existsById(autor.getId())) {
	            System.out.println("El autor con ID " + autor.getId() + " ya existe");
	            model.addAttribute("error", "La ID del autor tiene que ser única");
	            model.addAttribute("libro", new Libro());
	            model.addAttribute("autores", repositorioAutor.findAll());
	            return "alejandria";
	        } else {
	            repositorioAutor.save(autor);
	            System.out.println("Autor guardado correctamente.");
	            return "redirect:/";
	        }
	    }
	}

	@PostMapping("/crearLibro")
	public String creamosLibro(Model model, @Valid Libro libro, BindingResult resultado) {
	    if (resultado.hasErrors()) {
	        System.out.println("Errores al crear libro");

	        model.addAttribute("autor", new Autor());
	        model.addAttribute("autores", repositorioAutor.findAll());
	        model.addAttribute("libros", repositorioLibro.findAll());

	        return "alejandria";
	    } else {
	        System.out.println("Sin errores al crear libro");
	        repositorioLibro.save(libro);
	        return "redirect:/";
	    }
	}

	
	
	
	
}
