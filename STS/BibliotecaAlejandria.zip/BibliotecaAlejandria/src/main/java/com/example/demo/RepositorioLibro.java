package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface RepositorioLibro extends CrudRepository<Libro,Long> {

}
